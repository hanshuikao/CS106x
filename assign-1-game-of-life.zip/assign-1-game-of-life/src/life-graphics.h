/**
 * File: life-graphics.h
 * ---------------------
 * Defines a display class needed for the Game of Life assignment.
 * Based on an earlier version written by Julie Zelenski.
 */

#pragma once
#include <string>    // for std::string
#include "gwindow.h" // for GWindow
#include "vector.h"  // for Vector
#include "grid.h"    // for Grid

class LifeDisplay {
public:
/**
 * Constructs a Life window and makes it visible.
 */
    LifeDisplay();
    
/**
 * Hides the Life display window and then destroys it.
 */
    ~LifeDisplay();
    
/**
 * Updates the title of the window to specified string.
 */
    void setTitle(const std::string& title);
    
/**
 * This will erase the graphics window completely and draw a black
 * border around the simulation rectangle which is centered in the
 * window.  The grid cells will be sized as large as will fit given
 * the grid geometry. Grids with more rows and columns will use smaller
 * cells. This function can be used at the beginning of a simulation or
 * between generations to clear the window before drawing the next generation.
 */
    void setDimensions(int rows, int cols); //重新绘制特定行列数的网格，会清除旧网格，计算细胞的直径和初始位置。
    
 /**
  * Draws the cell at the specific row and column, replacing any previously
  * drawn cell at that location.  Rows and columns are specified using zero-based
  * indexing and (0,0) is the upper-left corner. If the location given is not in bounds,
  * an error is thrown.
  *
  * At startup, a random color is chosen for the simulation.  Each cell
  * will be displayed in a shade which tells its age.  Cells that have just
  * been born (i.e. that have value 1) are the darkest, they get lighter with
  * age as the values go to 2, 3, and so on.  The cells stabilize as very faint
  * at generation MaxAge and older.  Passing 0 for age means the cell is not alive,
  * the cell is drawn in white, erasing any previous contents.
  *
  * Note that this function does not directly repaint the graphical window.
  * display.repaint() must be called separately by the client to show updates to the GUI.
  */
    void drawCellAt(int row, int column, int age); //设定特殊位置细胞的年龄

 /**
  * Repaints the graphics window.
  */
    void repaint() { window.repaint(); } // 重新绘制窗口

 /**
  * Prints the current board with ages. Used for debugging and for
  * text-only versions of the program.
  *
  * Example output:
  *                    Game of Life
  *                    1  2  1  0  0
  *                    0  1  0  0  0
  *                    0  0  0  0  0
  *                    0  0  0  0  4
  */
    void printBoard(); //打印细胞年龄

private:
    GWindow window;
    int numRows;
    int numColumns;
    double upperLeftX;
    double upperLeftY;
    double cellDiameter;
    Vector<std::string> colors;
    std::string windowTitle;
    Grid<int> ages;
    Grid<GOval*> cells; // to avoid redrawing duplicate cells
    
    static const std::string kDefaultWindowTitle;
    static const int kDisplayWidth = 10 * 72; // 10 inches
    static const int kDisplayHeight = 7 * 72; // 7 inches
    
    void initializeColors(); //初始化细胞的颜色
    void fillCellGrid(); //填充网格 负责图形化，而setDimensions负责逻辑部分填充网格，fillCellGrid 发生在setDimensions 之后。
    int scalePrimaryColor(int baseContribution, int age) const; //调整细胞颜色，根据age 与 kmaxage 比例计算剩余contribute调整颜色
    void computeGeometry(); //计算细胞直径cellDiamerter和游戏网格左上角的upperleftx与upperlefty
    bool coordinateInRange(int row, int column) const; //检查给定的坐标是否在游戏网格内
    LifeDisplay(const LifeDisplay& original); //拷贝函数
    void operator=(const LifeDisplay& rhs) const; //可以使用🟰
};


