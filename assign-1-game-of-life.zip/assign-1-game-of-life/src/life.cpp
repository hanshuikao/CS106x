/**
 * File: life.cpp
 * --------------
 * Implements the Game of Life.
 */

#include <iostream>  // for cout
using namespace std;
#include <cstdlib> //用于获取当前目录路径
#include "console.h" // required of all files that contain the main function
#include "simpio.h"  // for getLine
#include "gevent.h" // for mouse event detection
#include "strlib.h"

#include "life-constants.h"  // for kMaxAge
#include "life-graphics.h"   // for class LifeDisplay
#include <fstream> // 用于打开文件


/**
 * Function: welcome
 * -----------------
 * Introduces the user to the Game of Life and its rules.
 */
static void welcome() {
    cout << "Welcome to the game of Life, a simulation of the lifecycle of a bacteria colony." << endl;
    cout << "Cells live and die by the following rules:" << endl << endl;
    cout << "\tA cell with 1 or fewer neighbors dies of loneliness" << endl;
    cout << "\tLocations with 2 neighbors remain stable" << endl;
    cout << "\tLocations with 3 neighbors will spontaneously create life" << endl;
    cout << "\tLocations with 4 or more neighbors die of overcrowding" << endl << endl;
    cout << "In the animation, new cells are dark and fade to gray as they age." << endl << endl;
    getLine("Hit [enter] to continue....   ");
}

/**
 * Function: main
 * --------------
 * Provides the entry point of the entire program.
 */
int main() {
    LifeDisplay display;
    display.setTitle("Game of Life");
    welcome();
    cout << "You can start your colony with random cells or read from a prepared file." << endl;
    string ps = "/Users/hanshuikao/Desktop/assign-1-game-of-life/res/files/";
    string ns = getLine("Enter name of colony file (or RETURN to seed randomly): ");
    bool isOpen = false;
    bool isPrint = false;
    bool Balanced = false;
    int columns = 0;
    int rows = 0;
    char c = '-';
    char d = 'X';

    while(true) {
        ifstream file(ps + ns); //打开初始状态的文件夹
        if (!file.is_open()){
            cout << "Unable to open the file named " << "\"" << ns << "\"." << " Please select another file." << endl;
            ns = getLine("Enter name of colony file (or RETURN to seed randomly): ");
        } else if (!isOpen) {
            ifstream file(ps + ns);
            cout << "this is the file: " << ns << endl;
            string line;
            bool isColumn = false;

            // get the rows and columns
            while (getline(file, line)) {
                char temp = line[0];
                if (temp == c || temp == d) {
                    if (isColumn == false) {
                        for (int i = 0; i < line.length(); i++) {
                            columns++;
                        }
                        isColumn = true;
                    }
                    rows++;
                }
            }

            cout << "rows: " << rows << endl;
            cout << "columns: " << columns << endl;

            file.close();
            isOpen = true;
        } else if (isOpen && !isPrint) {
            ifstream file(ps + ns);
            string line2;

            // Grid <datatype> grid(rows, colums);
            Grid <int> grid1(rows, columns);
            Grid <int> grid2(rows, columns);

            // set the age to each location at the grid1
            int rowGrid = 0;
            while (getline(file, line2)) {
                char temp = line2[0];
                if (temp == c || temp == d) {
                    for (int j = 0; j < columns; j++) {
                        temp = line2[j];
                        if (temp == c) {
                            grid1[rowGrid][j] = 0;
                        } else if (temp == d) {
                            grid1[rowGrid][j] = 1;
                        }
                    }
                    rowGrid++;
                }
            }
            while (!Balanced) {
                // test the primary grid1
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {
                        cout << grid1[i][j];
                    }
                    cout << endl;
                }
                isPrint = true;

                // transfer the number matrix to the GUI
                display.setTitle(ns);
                display.setDimensions(rows, columns);
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {
                        display.drawCellAt(i, j,grid1[i][j]);
                    }
                }

                getLine("next generation:");
                cout << "ok" << endl;

                // iterator the grid1 and update the age, store it to the grid2
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {
                        int NumAlive = 0;
                        int x = grid1[i][j];
                        for (int m = i - 1; m < i + 2; m++) {
                            if (m > rows - 1) {break;} // 当到最下面一排的时候，只需要检测相邻两个位置，不需要检测下一排
                            for (int n = j - 1; n < j + 2; n++) {
                                if (m < 0) {m = 0;}
                                if (n < 0) {n = 0;}
                                if (n > columns - 1) {break;} // 最右边一竖列只要检测左边一列
                                if (!(m == i && n == j)) {
                                    if (grid1[m][n] > 0 && grid1[m][n] < kMaxAge) {
                                        NumAlive++;
                                    }
                                }
                            }
                        }
                        if (NumAlive == 1 || NumAlive == 0) {
                            grid2[i][j] = 0;
                        } else if (NumAlive == 2) {
                            if (x == 0) {grid2[i][j] = 0;}
                            if (x != 0) {grid2[i][j] = x + 1;}
                        } else if (NumAlive == 3) {
                            grid2[i][j] = x + 1;
                        } else if (NumAlive >= 4) {
                            grid2[i][j] = 0;
                        }
                    }
                }

                // update the grid1
                for (int i = 0; i < rows; i++) {
                    for (int j = 0; j < columns; j++) {
                        grid1[i][j] = grid2[i][j];
                    }
                }

                // test if the matrix is balanced
            }
        }
    }
    return 0;
}

